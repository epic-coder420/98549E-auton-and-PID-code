# 98549E-code-2025-v2
V2 with new implemented code for auton and pid some reason even though code has no errors and is built correctly doesnt operate
